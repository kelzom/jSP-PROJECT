
package CLASSES;


public abstract class User 
{
    private String UserID;
    private String Username;
    private String Password;
    private String ContactInfo;
    private String UserRole;

    public User(String UserID, String Username, String Password, String ContactInfo, String UserRole) {
        this.UserID = UserID;
        this.Username = Username;
        this.Password = Password;
        this.ContactInfo = ContactInfo;
        this.UserRole = UserRole;
    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String UserID) {
        this.UserID = UserID;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getContactInfo() {
        return ContactInfo;
    }

    public void setContactInfo(String ContactInfo) {
        this.ContactInfo = ContactInfo;
    }

    public String getUserRole() {
        return UserRole;
    }

    public void setUserRole(String UserRole) {
        this.UserRole = UserRole;
    }
    
    
     public abstract void performRoleDuties();
    
}
