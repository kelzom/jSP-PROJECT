/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CLASSES;



public class AdminUser extends User
{

 
    public AdminUser(String UserID, String Username, String Password, String ContactInfo, String UserRole) {
        super(UserID, Username, Password, ContactInfo, UserRole);

    }
    @Override
    public void performRoleDuties()
    {
        
    }
    

   
}

