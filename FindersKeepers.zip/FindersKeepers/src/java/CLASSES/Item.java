/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CLASSES;

public class Item 
{
    private int item_id;
    private String title;
    private String description;
    private String category;
    private String status; 
    private int userId; 

    public Item(int item_id, String title, String description, String category, String status, int userId) {
        this.item_id = item_id;
        this.title = title;
        this.description = description;
        this.category = category;
        this.status = status;
        this.userId = userId;
    }

    public int getItem_id() {
        return item_id;
    }

    public void setItem_id(int item_id) {
        this.item_id = item_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "Item{" + "item_id=" + item_id + ", title=" + title + ", description=" + description + ", category=" + category + ", status=" + status + ", userId=" + userId + '}';
    }
       
    
}


