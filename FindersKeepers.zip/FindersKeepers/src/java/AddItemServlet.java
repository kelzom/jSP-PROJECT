import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import CLASSES.Item;
import Databases.KeepersDatabase;

@WebServlet("/AddItem")
public class AddItemServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String category = request.getParameter("category");
        String status = request.getParameter("status");
        int userId = Integer.parseInt(request.getParameter("user_id"));

        // Create an Item object
        Item newItem = new Item(0,title, description, category, status, userId);

        // Use KeepersDatabase to insert the new item into the database
        KeepersDatabase keepersDB = new KeepersDatabase();
        keepersDB.addItem(newItem); // Redirect to an error page
        response.sendRedirect("success.jsp"); // Redirect to a success page
    }
}
