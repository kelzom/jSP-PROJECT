package Servlet;

import CLASSES.Item;
import Databases.KeepersDatabase;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet("/about")
public class About extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/About.jsp"); // Make sure the path is correct
            KeepersDatabase db  = new KeepersDatabase();
        
            System.out.print("inserting");
            Item item = new Item(2,"hijju","ahdfjahnf","aknfa","lost",1);
            ArrayList<Item> arr  = db.getItems();
            System.out.print("Inserted");
        
         try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AuthServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AuthServlet herer at " + request.getContextPath() + "</h1>");
                        out.println("<h1>Servlet AuthServlet herer at " + arr + "</h1>");

            out.println("</body>");
            out.println("</html>");
        }
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    public String getServletInfo() {
        return "About Servlet"; 
    }
}

