package Servlet;

import CLASSES.Item;
import Databases.KeepersDatabase;
import dao.ItemDAOImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/updateItem")
public class UpdateItemServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int itemId = Integer.parseInt(request.getParameter("itemId"));

        KeepersDatabase db = new KeepersDatabase();
        Item item = db.getItem(Integer.toString(itemId));

        request.setAttribute("item", item);
        request.getRequestDispatcher("/updateItemForm.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int itemId = Integer.parseInt(request.getParameter("itemId"));
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String category = request.getParameter("category");
        String status = request.getParameter("status");
        int userId = Integer.parseInt(request.getParameter("userId"));

        Item updatedItem = new Item(itemId, title, description, category, status, userId);

       ItemDAOImpl dao = new ItemDAOImpl();

        dao.updateItem(updatedItem);

        response.sendRedirect("/FindersKeepers/item"); // Redirect to the list of items or a confirmation page
    }
}
