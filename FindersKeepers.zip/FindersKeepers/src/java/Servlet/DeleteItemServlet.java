package Servlet;

import Databases.KeepersDatabase;
import dao.ItemDAOImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/deleteItem")
public class DeleteItemServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int itemId = Integer.parseInt(request.getParameter("itemId"));

         ItemDAOImpl dao = new ItemDAOImpl();
        boolean deleteSuccess = dao.deleteItem(itemId);


        if (deleteSuccess) {
            // Redirect to a confirmation page 
            response.sendRedirect("/FindersKeepers/item"); 
        } else {
            // Handle the error scenario
            response.sendRedirect("errorPage.jsp"); 
        }
    }
}
