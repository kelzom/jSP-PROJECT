package Databases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import CLASSES.Item;
import java.util.ArrayList;

public class KeepersDatabase {
    private String connectionUrl = "jdbc:mysql://localhost:3306/finderskeepers";
    private String driver = "com.mysql.cj.jdbc.Driver";	
	private static Connection connection;
	// Open Connection to database
	public void startConnection(){
		try{
			Class.forName(driver);
			System.out.println("JDBC Driver loaded. Connecting to database....");
			connection = DriverManager.getConnection(connectionUrl, "root","root");
			System.out.println("Database Connected.");
		}catch(ClassNotFoundException | SQLException ex){
			ex.printStackTrace();					
		}
	}
  // close connection
	private void closeConnection() {
		try {
			connection.close();
		} catch (SQLException e) {
			System.out.println("[DB] Unable to close connection.");
			e.printStackTrace();
		}
	}
    
    public  void insertData() throws SQLException, ClassNotFoundException {
        startConnection();
        String insertUserSQL = "INSERT INTO users (username, password, contact_info, user_role) VALUES (?, ?, ?, ?)";
        System.out.print("Inserting data to database");
 try {
           PreparedStatement pstmtUser = connection.prepareStatement(insertUserSQL);
            pstmtUser.setString(1, "Jackie");
            pstmtUser.setString(2, "jackspassword");
            pstmtUser.setString(3, "Jackie@gmail.com");
            pstmtUser.setString(4, "STANDARD");
            pstmtUser.executeUpdate();

            pstmtUser.setString(1, "Christian");
            pstmtUser.setString(2, "chrispassword");
            pstmtUser.setString(3, "Christain@yahoo.com");
            pstmtUser.setString(4, "ADMIN");
            pstmtUser.executeUpdate();

            pstmtUser.setString(1, "Milly");
            pstmtUser.setString(2, "millyspassword");
            pstmtUser.setString(3, "Millybob@gmail.com");
            pstmtUser.setString(4, "MODERATE");
            pstmtUser.executeUpdate();
            pstmtUser.close();
	    closeConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}

            
            String insertItemSQL = "INSERT INTO items (title, description, category, status, user_id) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmtItem = connection.prepareStatement(insertItemSQL)) {
                pstmtItem.setString(1, "Lost Wallet");
                pstmtItem.setString(2, "Black leather wallet with some cash and credit cards.");
                pstmtItem.setString(3, "Personal");
                pstmtItem.setString(4, "LOST");
                pstmtItem.setInt(5, 1); 
                pstmtItem.executeUpdate();

                pstmtItem.setString(1, "Found Keys");
                pstmtItem.setString(2, "Set of car keys found near the library entrance.");
                pstmtItem.setString(3, "Accessories");
                pstmtItem.setString(4, "FOUND");
                pstmtItem.setInt(5, 2); 
                pstmtItem.executeUpdate();

                pstmtItem.setString(1, "Lost Watch");
                pstmtItem.setString(2, "Silver wristwatch with a blue face.");
                pstmtItem.setString(3, "Personal");
                pstmtItem.setString(4, "LOST");
                pstmtItem.setInt(5, 3); 
                pstmtItem.executeUpdate();
            }
        }
    
    // Add a new item to the database
    public void addItem(Item item) {
        startConnection();
        String query = "INSERT INTO items (title, description, category, status, user_id) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, item.getTitle());
            preparedStatement.setString(2, item.getDescription());
            preparedStatement.setString(3, item.getCategory());
            preparedStatement.setString(4, item.getStatus().toString());
            preparedStatement.setInt(5, item.getUserId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Get an item from the database
    public Item getItem(String itemID) {
        String query = "SELECT * FROM items WHERE item_id = ?";
        Item item = null;
        try {
        startConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, itemID);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                item = new Item(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getInt(6));
            }
            closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return item;
    }
        // Get an item from the database
    public ArrayList<Item> getItems() {
        String query = "SELECT * FROM items";
        Item item = null;
        try {
        startConnection();
            ArrayList<Item> arr = new ArrayList<>();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                item = new Item(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getInt(6));
                arr.add(item);
            }
            closeConnection();
         return arr;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
 
public boolean updateItem(Item item) {
    String query = "UPDATE items SET title = ?, description = ?, category = ?, status = ?, user_id = ? WHERE item_id = ?";
    try {
        startConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, item.getTitle());
        preparedStatement.setString(2, item.getDescription());
        preparedStatement.setString(3, item.getCategory());
        preparedStatement.setString(4, item.getStatus());
        preparedStatement.setInt(5, item.getUserId());
        preparedStatement.setInt(6, item.getItem_id());

        int rowsAffected = preparedStatement.executeUpdate();
        closeConnection();
        return rowsAffected > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
public boolean deleteItem(int itemId) {
    String query = "DELETE FROM items WHERE item_id = ?";
    try {
        startConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, itemId);

        int rowsAffected = preparedStatement.executeUpdate();
        closeConnection();
        return rowsAffected > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}


}