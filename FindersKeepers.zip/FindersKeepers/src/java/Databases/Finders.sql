

DROP DATABASE IF EXISTS FindersKeepers;
CREATE DATABASE FindersKeepers;
USE FindersKeepers;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    contact_info VARCHAR(255),
    user_role ENUM('ADMIN', 'MODERATE', 'STANDARD') NOT NULL,
    CONSTRAINT PK_users PRIMARY KEY(user_id)
);

CREATE TABLE items (
    item_id INT AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50),
    status ENUM('LOST', 'FOUND') NOT NULL,
    user_id INT,
    CONSTRAINT PK_items PRIMARY KEY(item_id),
    CONSTRAINT FK_items_users FOREIGN KEY(user_id) REFERENCES users(user_id)
);

