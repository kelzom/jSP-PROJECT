
package UtilityInterfaces;


public interface EmailSender {
    
    void sendEmail(String toAddress, String subject, String body);
}


