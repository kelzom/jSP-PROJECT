
package UtilityInterfaces;


public interface Authenticator 
{
 
    boolean authenticate(String username, String password);
}

