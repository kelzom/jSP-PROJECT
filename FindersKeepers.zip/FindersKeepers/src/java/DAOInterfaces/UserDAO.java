/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOInterfaces;

import CLASSES.User;

/**
 *
 * @author kellzom
 */
public interface UserDAO 
{

    void addUser(User user);
    User getUser(String userID);
    void updateUser(User user);
    void deleteUser(String userID);
}


