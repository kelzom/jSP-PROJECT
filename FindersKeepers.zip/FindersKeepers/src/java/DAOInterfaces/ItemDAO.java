
package DAOInterfaces;


import CLASSES.Item;
import java.util.ArrayList;

public interface ItemDAO {

    void addItem(Item item);
    Item getItem(int itemID);
    ArrayList<Item> getItems();
    boolean updateItem(Item item);
    boolean deleteItem(int itemID);

}
