
package factory;

import CLASSES.AdminUser;
import CLASSES.ModerateUser;
import CLASSES.StandardUser;
import CLASSES.User;
import Enumerations.UserRole;

public class UserFactory
{

public static User createUser(UserRole role, String UserID, String Username, String Password, String ContactInfo, String UserRole) 
{
    switch (role) {
        case ADMIN:
            return new AdminUser(UserID, Username, Password, ContactInfo, "ADMIN");
        case MODERATOR:
            return new ModerateUser(UserID, Username, Password, ContactInfo, "MODERATOR");
        default:
            return new StandardUser(UserID, Username, Password, ContactInfo, "STANDARD_USER");
    }
}
}
