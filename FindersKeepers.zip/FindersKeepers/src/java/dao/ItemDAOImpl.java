package dao;


import CLASSES.Item;
import DAOInterfaces.ItemDAO;
import Databases.KeepersDatabase;
import java.util.ArrayList;

public class ItemDAOImpl implements ItemDAO {

    private KeepersDatabase db;

    public ItemDAOImpl() {
        db = new KeepersDatabase(); 
    }

    @Override
    public void addItem(Item item) {
         db.addItem(item);

    }

    @Override
    public Item getItem(int itemID) {
        return db.getItem(String.valueOf(itemID));
    }

    @Override
    public ArrayList<Item> getItems() {
        return db.getItems();
    }

    @Override
    public boolean updateItem(Item item) {
        return db.updateItem(item);
    }

    @Override
    public boolean deleteItem(int itemID) {
        return db.deleteItem(itemID);
    }

}
