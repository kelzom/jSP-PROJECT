
package ServiceInterfaces;

import CLASSES.User;

/**
 *
 * @author kellzom
 */
public interface UserService 
{
  
    void registerUser(User user);
    User loginUser(String username, String password);
    void updateUserDetails(User user);
  
}


