
package ServiceInterfaces;

import CLASSES.Item;

public interface ItemService 
{
  
    void reportLostItem(Item item);
    void reportFoundItem(Item item);
   
}


